/*
  File: bluetooth.win.c

  Contributors: Milan Cermak; milan.cermak@gmail.com

  Description: libbtnxlisp source file for Linux and Windows XP SP2
               All functions are called from Common Lisp

 */

/*
  TODO: there's probably no need for the channel argument in some
        related functions - when talking to the NXT through BT, it
	has to be in slave mode -> we have to be connected on the
	first channel (slot 0 on NXT's display)


/* * * * * * * * * * * * *

 for Win compilation, #define NXT_WIN_XP
 Win XP with Servise Pack 2 is a prerequisite
 
 * * * * * * * * * * * * */

#ifdef NXT_WIN_XP

#include <Winsock2.h>
#include <Ws2bth.h>
#include <Bthsdpdef.h>
#include <BluetoothAPIs.h>

#else

#include <unistd.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/rfcomm.h>
#include <bluetooth/hci.h>
//#include <bluetooth/hci_lib.h>

#endif

#include <errno.h>
#include "bluetooth.h"


#ifdef NXT_WIN_XP
// a Windows specific function to initialise the BT stack (or something)
int win_init(void) {
  WORD version;
  WSADATA wsa;
  int error;

  version = MAKEWORD(2,2);
  error = WSAStartup(version, &wsa);

  if (error != 0)
    return -1;
  if ((LOBYTE(wsa.wVersion) != 2) ||
      (HIBYTE(wsa.wVersion) != 2)) {
    WSACleanup();
    return -1;
  }

  return 0;

} // win_init()
#endif

/*
  Functions connects to an NXT brick specified by the nxt_address
  argument on the requested channel (port in BT terminology). If
  channel is out of range (valid values are 1-30 inclusive), it uses
  the first available channel.
  Function returns a socket descriptor on success or -1 otherwise.
  
 */
int open_nxt_stream(char *nxt_address, int *channel) {
#ifdef NXT_WIN_XP

  int nxt_socket, chan = *channel;
  struct SOCKADDR_BTH nxt;

  int err = win_init();
  if (err < 0)
    return -1;
  
  nxt_socket = socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
  if (nxt_socket < 0)
    return -1;

  nxt.addressFamily = AF_BTH;
  nxt.btAddr = 0;

#else
  
  int nxt_socket, chan = *channel;
  struct sockaddr_rc nxt = { 0 };
 
  nxt_socket = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

  if (nxt_socket < 0)
    return -1;

  nxt.rc_family = AF_BLUETOOTH;
  str2ba(nxt_address, &nxt.rc_bdaddr);

#endif
  /* is this really necessary? I have a feeling the only possible way
     to connect to the NXT is through channel 1; investigate!
  */
  if ((chan < 1) || (chan > 30)) {
    // use first available channel if illegal requested
    int i, status;
    for (i = 1; i <= 30; i++) {
      nxt.port = i;
      status = connect(nxt_socket, (struct sockaddr*) &nxt, sizeof(nxt));
      if ((status < 0) && (i < 30))
	continue;  // try the next one
      else if ((status < 0) && (i == 30))
	return -1; // no available channel
      else {
	*channel = i; // connected
	break;
      }
    }
  }
  else {
    // user specified a legal channel
    nxt.port = chan;
    int status;
    status = connect(nxt_socket, (struct sockaddr*) &nxt, sizeof(nxt));
    if (status < 0)
      return -1;
  }

  return nxt_socket;

} // open_nxt_stream()

/*
  If nxt_socket == 0, we're debugging packets in CL. This functions
  serves as a wrapper and to keep things simpler and consistent higher.
*/
int close_nxt_stream(int nxt_socket) {
  
  return (nxt_socket == 0) ? 0 : close(nxt_socket);
  
} // close_nxt_stream()

/*
 Function for sending data to an NXT. It tries to send() the
 the whole package. Package has to be correctly constructed in CL.
 It takes three argument - nxt_socket is the descriptor of the
 socket, msg is a pointer to the packet buffer and length is the
 length of the packet (msg).
 It returns 0 on success and -1 on failure, in which case length
 carries the total bytes sent.
 TODO: update comment
*/
int send_msg(int nxt_socket, unsigned char *msg, int length,
	     int block, int timeout,
	     int retries, int retries_interval) {
#ifdef NXT_WIN_XP
  int sent = 0;             // already sent bytes
  int remaining = length;  // bytes not sent yet
  int b;  // bytes sent in one send()

  /*
    handle additional connection-specifying data
    semantics is described in the user's manual
  */

  int retries_done, send_flag;
  int do_retries = 0, do_timeout = 0;

  /* this handles all 4 possible settings:
     - both retries and timeout are zero
     - retries is set, timeout is zero
     - retries is zero, timeout is set
     - both retries and timeout are set (handled by 2nd if)
  */
  if ((retries == 0) && (timeout == 0))
    // in linux, it works this way: send_flag = (block == 0) ? 0 :
    // MSG_DONTWAIT;
    send flag = 0;
  else if (retries != 0) {
    // priority: retries > timeout
    send_flag = 0;
    do_retries = 1;
    retries_done = 0;
  }
  else if (timeout != 0) {
    send_flag = 0;
    do_timeout = 1;    
  }

  // act accordingly
  if (!do_retries && !do_timeout) {
    // no retries, no timeout
    b = (int) send(nxt_socket, msg, remaining, send_flag);
    if (b != -1)
      sent = b;
  }
  else if (do_retries) {
    // send with retries
    while ((retries_done <= retries) ||
	   (sent < length)) {
      if (retries_done != 0)
	sleep(retries_interval);
      b = (int) send(nxt_socket, msg+sent, remaining, send_flag);
      if (b != -1) {
	sent += b;
	remaining -= b;
      }
      retries_done++;
    }
  }
  else if (do_timeout) {
    // send with timeout (implemented as a pseudo-timeout)
    b = (int) send(nxt_socket, msg, remaining, send_flag);
    if (b != -1) {
      sent += b;
      remaining -= b;
    }
    if (b < length) {
      // didn't send the whole package
      sleep(timeout);
      b = (int) send(nxt_socket, msg+sent, remaining, send_flag);
      if (b != -1) {
	sent += b;
	remaining -= b;
      }
    }
  }

#else
  
  int sent = 0;             // already sent bytes
  int remaining = length;   // bytes not sent yet
  int b;  // bytes sent in one send()

  /*
    handle additional connection-specifying data
    semantics is described in the user's manual
  */

  int retries_done, send_flag = MSG_DONTWAIT;
  int do_retries = 0, do_timeout = 0;

  /* this handles all 4 possible settings:
     - both retries and timeout are zero
     - retries is set, timeout is zero
     - retries is zero, timeout is set
     - both retries and timeout are set (handled by 2nd if)
  */
  if ((retries == 0) && (timeout == 0))
    send_flag = (block == 0) ? 0 : MSG_DONTWAIT;
  else if (retries != 0) {
    // priority: retries > timeout
    send_flag = MSG_DONTWAIT;
    do_retries = 1;
    retries_done = 0;
  }
  else if (timeout != 0) {
    send_flag = MSG_DONTWAIT;
    do_timeout = 1;    
  }

  // act accordingly
  if (!do_retries && !do_timeout) {
    // no retries, no timeout
    b = (int) send(nxt_socket, msg, remaining, send_flag);
    if (b != -1)
      sent = b;
  }
  else if (do_retries) {
    // send with retries
    while ((retries_done <= retries) ||
	   (sent < length)) {
      if (retries_done != 0)
	sleep(retries_interval);
      b = (int) send(nxt_socket, msg+sent, remaining, send_flag);
      if (b != -1) {
	sent += b;
	remaining -= b;
      }
      retries_done++;
    }
  }
  else if (do_timeout) {
    // send with timeout (implemented as a pseudo-timeout)
    b = (int) send(nxt_socket, msg, remaining, send_flag);
    if (b != -1) {
      sent += b;
      remaining -= b;
    }
    if (b < length) {
      // didn't send the whole package
      sleep(timeout);
      b = (int) send(nxt_socket, msg+sent, remaining, send_flag);
      if (b != -1) {
	sent += b;
	remaining -= b;
      }
    }
  }

#endif    
  return sent;
} // send_msg()


/*
 Function for receiving data from an NXT. It tries to recv()
 the whole packet.
 It takes three arguments - nxt_socket is the descriptor of the
 socket, msg is a pointer to a buffer in which the packet will
 be stored and length represents how many bytes to receive (should
 be the length of msg).
 The operation is non-blocking - if the user demands receiving more
 bytes than there are available, the function ends, returning number
 of bytes successfully read until that point.
 Function returns number of bytes received on success and -1 on failure,
 in which case length holds total received bytes.
 TODO: update comment
*/
int recv_msg(int nxt_socket, unsigned char *msg, int length,
	     int block, int timeout,
	     int retries, int retries_interval) {
#ifdef NXT_WIN_XP
  int received = 0;          // already received bytes
  int remaining = length;   // bytes yet to be received
  int b;

    /*
    handle additional connection-specifying data
    semantics is described in the user's manual
  */

  int retries_done, recv_flag;
  int do_retries = 0, do_timeout = 0;

  /* this handles all 4 possible settings:
     - both retries and timeout are zero
     - retries is set, timeout is zero
     - retries is zero, timeout is set
     - both retries and timeout are set (handled by 2nd if)
  */
  if ((retries == 0) && (timeout == 0))
    //    recv_flag = (block == 0) ? 0 : MSG_DONTWAIT;
    recv_flag = 0;
  else if (retries != 0) {
    // priority: retries > timeout
    recv_flag = 0;
    do_retries = 1;
    retries_done = 0;
  }
  else if (timeout != 0) {
    recv_flag = 0;
    do_timeout = 1;    
  }

  
  // act accordingly
  if (!do_retries && !do_timeout) {
    // no retries, no timeout
    b = (int) recv(nxt_socket, msg, remaining, recv_flag);
    if (b != -1)
      received = b;
  }
  else if (do_retries) {
    // receive with retries
    while ((retries_done <= retries) ||
	   (received < length)) {
      if (retries_done != 0)
	sleep(retries_interval);
      b = (int) recv(nxt_socket, msg+received, remaining, recv_flag);
      if (b == 0)
	break;
      else if (b != -1) {
	received += b;
	remaining -= b;
      }
      retries_done++;
    }
  }
  else if (do_timeout) {
    // receive with timeout (implemented as a pseudo-timeout)
    b = (int) recv(nxt_socket, msg, remaining, recv_flag);
    if (b != -1) {
      received += b;
      remaining -= b;
    }
    if (b < length) {
      // didn't receive the whole package
      sleep(timeout);
      b = (int) recv(nxt_socket, msg+received, remaining, recv_flag);
      if (b != -1) {
	received += b;
	remaining -= b;
      }
    }
  }

#else
  
  int received = 0;          // already received bytes
  int remaining = length;    // bytes yet to be received
  int b;

  /*
    handle additional connection-specifying data
    semantics is described in the user's manual
  */

  int retries_done, recv_flag = MSG_DONTWAIT;
  int do_retries = 0, do_timeout = 0;

  /* this handles all 4 possible settings:
     - both retries and timeout are zero
     - retries is set, timeout is zero
     - retries is zero, timeout is set
     - both retries and timeout are set (handled by 2nd if)
  */
  if ((retries == 0) && (timeout == 0))
    recv_flag = (block == 0) ? 0 : MSG_DONTWAIT;
  else if (retries != 0) {
    // priority: retries > timeout
    recv_flag = MSG_DONTWAIT;
    do_retries = 1;
    retries_done = 0;
  }
  else if (timeout != 0) {
    recv_flag = MSG_DONTWAIT;
    do_timeout = 1;    
  }

  
  // act accordingly
  if (!do_retries && !do_timeout) {
    // no retries, no timeout
    b = (int) recv(nxt_socket, msg, remaining, recv_flag);
    if (b != -1)
      received = b;
  }
  else if (do_retries) {
    // receive with retries
    while ((retries_done <= retries) ||
	   (received < length)) {
      if (retries_done != 0)
	sleep(retries_interval);
      b = (int) recv(nxt_socket, msg+received, remaining, recv_flag);
      if (b == 0)
	break;
      else if (b != -1) {
	received += b;
	remaining -= b;
      }
      retries_done++;
    }
  }
  else if (do_timeout) {
    // receive with timeout (implemented as a pseudo-timeout)
    b = (int) recv(nxt_socket, msg, remaining, recv_flag);
    if (b != -1) {
      received += b;
      remaining -= b;
    }
    if (b < length) {
      // didn't receive the whole package
      sleep(timeout);
      b = (int) recv(nxt_socket, msg+received, remaining, recv_flag);
      if (b != -1) {
	received += b;
	remaining -= b;
      }
    }
  }

#endif
  return received;
  
} // recv_msg()


/*
 A helper function; plays a tone (who would have guessed it?)
*/
void greeting_tone(int sock) {

  unsigned char comm[8];
  int len = 6;
  int hz = 1200, duration = 800;
  
  // construct the packet
  memcpy(&comm[0], &len, 2);
  comm[2] = 0x00; 
  comm[3] = 0x03; 
  memcpy(&comm[4], &hz, 2);
  memcpy(&comm[6], &duration, 2);

  int i;
  printf("message: \n");
  for (i = 0; i < 8; i++)
    printf("0x%02X ", comm[i]);
  printf("\n");

  write(sock, &comm, sizeof(comm));
  return;
  
} // greeting_tone()




//*****************************************************************************

// for testing purposes
// TODO: delete main() and greeting_tone() when stable

int main(void) {

  //TODO: if channel != 1, the NXT doesn't play a sound
  int socket, channel = 1;
  char *nxt_address = "00:16:53:01:5F:28";
  unsigned char buf[20] = { 0 };
  int ret, len = sizeof(buf);

  socket = open_nxt_stream(nxt_address, &channel);
  greeting_tone(socket);
  sleep(1);
  ret = recv_msg(socket, buf, len, 1, 0, 0, 0);
  
  printf("received: %d\n", ret);
  int i;
  for (i = 0; i < ret; i++)
    printf("0x%02X ", buf[i]);
  printf("\n");
  close_nxt_stream(socket);
  

  return 0;

}
