/*
  File: bluetooth.h

  Contributors: Milan Cermak; milan.cermak@gmail.com

  Description: Header file for bluetooth.h

 */


/*
 Function prototypes; for detailed description, see the .c file
*/

int open_nxt_stream(char *nxt_address, int *channel);

int close_nxt_stream(int nxt_socket);

int send_msg(int nxt_socket, unsigned char *msg, int length,
	     int block, int timeout,
	     int retries, int retries_interval);

int recv_msg(int nxt_socket, unsigned char *msg, int length,
	     int block, int timeout,
	     int retries, int retries_interval);

// for testing
void greeting_tone(int tmp_socket);
